<?php 
	include('connection.php');
	include('function.php');
	
	$myCondition = Array();
	if(isset($_REQUEST["name"]) && strlen($_REQUEST["name"]) > 0){
		$name = $_REQUEST["name"];
		array_push($myCondition," name LIKE '%".trim($name)."%' OR id LIKE '%".trim($name)."%'");
	}
	else
		$name = "";
	
	if(count($myCondition) > 0)
		$myCondition = " WHERE (".implode(" AND ", $myCondition).")";
	else
		$myCondition = "";
	
	if(!isset($_REQUEST["cpage"]) || intval($_REQUEST["cpage"])==0)
	$cpage=1;
	else
		$cpage = $_REQUEST["cpage"];

	$pagesize = 5;

	$startdisp = $pagesize*($cpage-1);
	
	$qry .= "select * from demo $myCondition";
	$qry .= " LIMIT $startdisp,$pagesize";
	$count = "select count(*) from demo $myCondition";
	
	$res = mysql_query($qry) or die ('Error :: in fetch data<br>'.mysql_error());
	$total_res = mysql_num_rows($res);
	$res_count = mysql_query($count) or die ('Error :: in count result<br>'.mysql_error());
	
	if($tcount=mysql_fetch_array($res_count))
		$fcount = $tcount[0];
	else
		$fcount = 1;
	
	$TotalPages = ceil(($fcount)/$pagesize);
	mysql_free_result($res_count);

?>
<center>
	<br>
	<form name="search_frm" id="search_frm" method="get" action="index.php" enctype="multipart/form-data">
		<div>
			<input type="text" name="name" value="<?php echo setGPC($name,"display"); ?>"/>
			<button type="submit">Search</button>
			<input name="btnfilter" type="button" class="btn-blue" value="Clear Filter" onclick="javascript:window.location='index.php';">
		</div>
	</form>
	<br>
	<form name="frm1" method="get" id="frm1" action="index.php" enctype="multipart/form-data">
		<table border="1" width="300">
			<tr>
				<th>ID</th>
				<th>Name</th>
			</tr>
			<?php if($total_res>0){ ?>
			<?php while($row = mysql_fetch_array($res)){ ?>
			<tr>
				<td><?php echo $row['id']; ?></td>
				<td><?php echo $row['name']; ?></td>
			</tr>
			<?php }}else{ ?>
			<tr>
				<td colspan="2" align="center">No results found</td>
			</tr>
			<?php } ?>
			<input type="hidden" name="cpage">
			<input type="hidden" name="name" value="<?php echo setGPC($name,"display")?>" />
		</table>
	</form>
	<?php DisplayPages($cpage,$TotalPages, "frm1","Admin_Link"); ?>
</center>